import * as React from 'react';
import { Box, LinearProgress, Stack, Typography } from '@mui/material';

const BarRow: React.FC<{ label: string; value?: number; max?: number }> = ({ label, value, max = 100 }) => {
  const v = typeof value === 'number' && isFinite(value) ? Math.max(0, Math.min(max, value)) : undefined;
  return (
    <Box>
      <Stack direction="row" alignItems="center" spacing={1} mb={0.5}>
        <Typography variant="body2" sx={{ width: 160, color: 'text.secondary' }}>{label}</Typography>
        <Box sx={{ flex: 1 }}>
          {typeof v === 'number'
            ? <LinearProgress variant="determinate" value={v} sx={{ height: 8, borderRadius: 999 }} />
            : <Box sx={{ height: 8, bgcolor: 'action.hover', borderRadius: 1 }} />}
        </Box>
        <Typography variant="body2" sx={{ width: 40, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
          {typeof v === 'number' ? Math.round(v) : '—'}
        </Typography>
      </Stack>
    </Box>
  );
};

export default function ScoreBreakdown(props: {
  score?: number;
  rsi14?: number;
  adx14?: number;
  relvol20?: number;
}) {
  return (
    <Box sx={{ mb: 2 }}>
      <Typography variant="subtitle2" sx={{ mb: 1 }}>Score</Typography>
      <BarRow label="Total Score" value={props.score} />
      {'rsi14' in props && <BarRow label="RSI(14)" value={props.rsi14} />}
      {'adx14' in props && <BarRow label="ADX(14)" value={props.adx14} />}
      {'relvol20' in props && <BarRow label="Accumulation / RelVol(20)" value={props.relvol20} />}
    </Box>
  );
}
