import * as React from 'react';
import { Box, Chip, IconButton, Stack, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { num, pct } from './utils';
import type { Badge as ApiBadge } from '@/lib/api/types';

type Props = {
  name?: string;
  sector?: string;
  price?: number;
  pctToday?: number;
  runId?: string;
  badges?: ApiBadge[] | Array<string | number>;
  onClose: () => void;
};

const muiColors = new Set(['default','primary','secondary','success','info','warning','error']);
const normBadge = (b: unknown) => {
  if (b == null) return { label: '—', color: 'default' as const };
  if (typeof b === 'string' || typeof b === 'number') return { label: String(b), color: 'default' as const };
  const x = b as ApiBadge;
  const label = x.label ?? x.text ?? x.code ?? x.key ?? 'Badge';
  const color = x.color && muiColors.has(x.color) ? (x.color as any) : 'default';
  return { label, color };
};

export default function DrawerHeader({
  name, sector, price, pctToday, runId, badges: rawBadges, onClose,
}: Props) {
  const badges = Array.isArray(rawBadges) ? rawBadges : [];

  return (
    <>
      <Stack direction="row" alignItems="flex-start" justifyContent="space-between">
        <Box sx={{ minWidth: 0 }}>
          <Typography variant="h6" sx={{ fontWeight: 700, pr: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {name || '—'}
          </Typography>
        </Box>
        <Stack spacing={0.25} alignItems="flex-end" sx={{ flexShrink: 0 }}>
          <Typography variant="h6" sx={{ fontVariantNumeric: 'tabular-nums' }}>{num(price)}</Typography>
          <Chip size="small" color={typeof pctToday === 'number' ? (pctToday >= 0 ? 'success' : 'error') : 'default'} label={pct(pctToday)} />
        </Stack>
        <IconButton onClick={onClose} aria-label="close" sx={{ ml: 1 }}>
          <CloseIcon />
        </IconButton>
      </Stack>

      {badges.length > 0 && (
        <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', mt: 1 }}>
          {badges.slice(0, 8).map((b, i) => {
            const nb = normBadge(b);
            return (
              <Chip
                key={`badge-${i}`}
                size="small"
                variant={nb.color === 'default' ? 'outlined' : 'filled'}
                color={nb.color as any}
                label={nb.label}
              />
            );
          })}
        </Stack>
      )}
    </>
  );
}
