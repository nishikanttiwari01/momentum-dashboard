import * as React from 'react';
import {
  Drawer, Box, Typography, Chip, Divider, Grid, Tooltip,
  IconButton, Button, Stack, TextField, Switch, Avatar, LinearProgress
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import WhatshotIcon from '@mui/icons-material/Whatshot';
import SpeedIcon from '@mui/icons-material/Speed';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import type { DrawerDetail } from '@/lib/api/types';
import { useInstrumentDetail } from '@/lib/hooks';
import { drawerPaperSx, sectionDividerSx } from './styles';

/** ----- Formatters ----- */
const pct = (v?: number, d = 2) => (typeof v === 'number' && isFinite(v) ? `${v.toFixed(d)}%` : '—');
const rup = (v?: number, d = 2) => (typeof v === 'number' && isFinite(v) ? `₹${v.toFixed(d)}` : '—');
const num = (v?: number, d = 2) => (typeof v === 'number' && isFinite(v) ? v.toFixed(d) : '—');
const relvol = (v?: number) => (typeof v === 'number' && isFinite(v) ? `${v.toFixed(2)}×` : '—');
const prox52w = (p?: number) => {
  if (typeof p !== 'number' || !isFinite(p)) return '—';
  return p === 0 ? 'At 52W high' : p > 0 ? `${pct(p)} above` : `${pct(Math.abs(p))} below`;
};

/** ----- Small atoms ----- */
const Row: React.FC<{ label: string; value: React.ReactNode; hint?: string }> = ({ label, value, hint }) => (
  <Stack direction="row" alignItems="baseline" spacing={1} sx={{ minWidth: 0 }}>
    <Typography variant="body2" sx={{ width: 100, color: 'text.secondary', flexShrink: 0 }}>{label}:</Typography>
    <Typography variant="body2" sx={{ fontVariantNumeric: 'tabular-nums' }}>{value}</Typography>
    {hint ? <Typography variant="caption" color="text.secondary">— {hint}</Typography> : null}
  </Stack>
);

/** ----- Analog meter (0–100) ----- */
const toScoreFromLevel = (level?: string) => {
  const l = (level || '').toLowerCase();
  if (l === 'low') return 25;
  if (l === 'medium') return 60;
  if (l === 'high') return 85;
  return undefined;
};

const scoreColor = (score?: number) => {
  if (typeof score !== 'number') return 'action.disabledBackground';
  if (score < 34) return 'success.main';
  if (score < 67) return 'warning.main';
  return 'error.main';
};

const AnalogMeter: React.FC<{
  icon: React.ReactNode;
  label: string;
  score?: number;                 // prefer meters.*.score_0_100 from backend
  level?: string;                 // fallback when score missing
  basis?: Record<string, number>; // tooltip explanation
}> = ({ icon, label, score, level, basis }) => {
  const v = typeof score === 'number' ? Math.max(0, Math.min(100, score)) : toScoreFromLevel(level);
  const title = basis && Object.keys(basis).length
    ? Object.entries(basis).map(([k, val]) => `${k}: ${typeof val === 'number' ? val.toFixed(2) : val}`).join(' · ')
    : '';

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
        {icon}
        <Typography variant="body2" sx={{ fontWeight: 700 }}>{label}</Typography>
        <Box sx={{ flex: 1 }} />
        <Typography variant="caption" color="text.secondary">
          {level ?? '—'}
        </Typography>
      </Stack>

      <Tooltip title={title} disableHoverListener={!title}>
        <Box sx={{ position: 'relative' }}>
          {/* Track */}
          <Box sx={{ height: 12, bgcolor: 'action.hover', borderRadius: 999, overflow: 'hidden' }} />
          {/* Fill */}
          <Box
            sx={{
              position: 'absolute',
              inset: 0,
              width: `${typeof v === 'number' ? v : 0}%`,
              bgcolor: scoreColor(v as number),
              borderRadius: 999,
              transition: 'width .25s ease',
            }}
          />
        </Box>
      </Tooltip>

      <Stack direction="row" justifyContent="space-between" sx={{ mt: 0.5 }}>
        <Typography variant="caption" color="text.secondary">0</Typography>
        <Typography variant="caption" color="text.secondary">50</Typography>
        <Typography variant="caption" color="text.secondary">100</Typography>
      </Stack>

      <Typography variant="caption" sx={{ mt: 0.25, display: 'inline-block', fontVariantNumeric: 'tabular-nums' }}>
        {typeof v === 'number' ? `${Math.round(v)}` : '—'}
      </Typography>
    </Box>
  );
};

type Props = { symbol: string | null; open: boolean; onClose: () => void };

export default function RightDrawer({ symbol, open, onClose }: Props) {
  const enabled = Boolean(open && symbol);
  const { data, isFetching, error } = useInstrumentDetail(symbol || '', undefined, {
    enabled,
    staleTimeMs: 60_000,
  });

  // Defensive read
  const d = (data as DrawerDetail | undefined) as any;
  const header = d?.header || {};
  const ind = d?.indicators || {};
  const meters = d?.meters || {};
  const pos = d?.position || {};
  const sb = d?.score_breakdown || {};
  const ab = d?.action_block || {};
  const na = d?.next_action || {};
  const refs = na?.refs || {};

  /** Effective entry precedence (frozen):
   * locked > entry > suggested > price
   */
  const locked = typeof pos?.entry_price_locked === 'number' && pos.entry_price_locked > 0;
  const effectiveEntry =
    (locked ? pos.entry_price_locked : pos?.entry_price) ?? refs?.entry_suggested ?? (d?.price ?? header?.price);

  // Local UI state (view-only flow; no POST wiring here)
  const [tradeOn, setTradeOn] = React.useState<boolean>(Boolean(pos?.trade_on));
  const [entryPrice, setEntryPrice] = React.useState<string>(typeof effectiveEntry === 'number' ? String(effectiveEntry) : '');
  const [qty, setQty] = React.useState<string>(pos?.qty ? String(pos.qty) : '');
  React.useEffect(() => {
    setTradeOn(Boolean(pos?.trade_on));
    const eff =
      (typeof pos?.entry_price_locked === 'number' && pos.entry_price_locked > 0 ? pos.entry_price_locked : pos?.entry_price) ??
      refs?.entry_suggested ?? (d?.price ?? header?.price);
    setEntryPrice(typeof eff === 'number' ? String(eff) : '');
    setQty(pos?.qty ? String(pos.qty) : '');
  }, [d?.price, header?.price, pos?.trade_on, pos?.entry_price, pos?.entry_price_locked, pos?.qty, refs?.entry_suggested]);

  const lockDisabled = !tradeOn || !entryPrice || Number(entryPrice) <= 0 || (qty && Number(qty) <= 0);

  // 1D change: prefer pct_today (new), fall back to older names
  const pct1d = header?.pct_1d ?? d?.pct_today ?? d?.change_pct_1d ?? d?.change_pct;
  const pctColor = typeof pct1d === 'number' ? (pct1d >= 0 ? 'success' : 'error') : 'default';

  // ----- Badges -----
  // Back-end may send them under header.badges (new) or top-level badges (old).
  const badgesRaw = Array.isArray(header?.badges) ? header.badges : (Array.isArray(d?.badges) ? d.badges : []);
  // valid MUI chip colors
  const muiColors = new Set(['default','primary','secondary','success','info','warning','error']);
  const normBadge = (b: any) => {
    // New contract: {category:'BREAKOUT'|'MOMENTUM'|'WATCH'|'IGNORE', label:string}
    if (b && typeof b === 'object' && 'category' in b && 'label' in b) {
      const cat = String(b.category || '').toUpperCase();
      const label = String(b.label || 'Badge');
      const color =
        cat === 'BREAKOUT' ? 'warning'
        : cat === 'MOMENTUM' ? 'success'
        : cat === 'IGNORE'   ? 'error'
        : 'default';
      return { label, color };
    }
    // Legacy object: {code, text, key, label, color}
    if (b && typeof b === 'object') {
      const label =
        (b.label && String(b.label)) ||
        (b.text && String(b.text)) ||
        (b.code && String(b.code)) ||
        (b.key && String(b.key)) ||
        'Badge';
      const color = muiColors.has(String(b.color)) ? (b.color as any) : 'default';
      return { label, color };
    }
    // Primitive fallback
    if (typeof b === 'string' || typeof b === 'number') return { label: String(b), color: 'default' as const };
    return { label: 'Badge', color: 'default' as const };
  };

  // ----- Score (new sb.score_total_0_100; fallback to d.score) -----
  const totalScore = typeof sb?.score_total_0_100 === 'number' ? sb.score_total_0_100 : d?.score;

  return (
    <Drawer anchor="right" open={open} onClose={onClose} PaperProps={{ sx: drawerPaperSx }}>
      {/* HEADER */}
      <Box sx={{ position: 'sticky', top: 0, zIndex: 2, px: 3, py: 1.25, bgcolor: 'background.paper', borderBottom: 1, borderColor: 'divider' }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={2}>
          <Stack direction="row" spacing={1.25} alignItems="center" sx={{ minWidth: 0 }}>
            <Avatar sx={{ width: 28, height: 28, bgcolor: 'primary.main', fontSize: 14 }}>
              {(d?.symbol_canon || header?.name || d?.name || symbol || '—').slice(0, 2).toUpperCase()}
            </Avatar>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6" noWrap title={header?.name || d?.name || symbol || '—'}>
                {header?.name || d?.name || symbol || '—'}
              </Typography>
              <Typography variant="caption" color="text.secondary" noWrap title={header?.sector || d?.sector || ''}>
                {(header?.sector || d?.sector || '—')}
                {d?.run_id ? ` · Run ${d.run_id}` : d?.resolved_run_id ? ` · Run ${d.resolved_run_id}` : ''}
              </Typography>
            </Box>
          </Stack>

        <Stack spacing={0.25} alignItems="flex-end" sx={{ flexShrink: 0 }}>
            <Typography variant="h6" sx={{ fontVariantNumeric: 'tabular-nums' }}>
              {rup(header?.price ?? d?.price)}
            </Typography>
            <Chip size="small" color={pctColor as any} label={pct(pct1d)} variant="filled" />
          </Stack>

          <IconButton onClick={onClose} aria-label="close" sx={{ flexShrink: 0 }}>
            <CloseIcon />
          </IconButton>
        </Stack>

        {/* Badges row */}
        <Stack direction="row" spacing={1} sx={{ mt: 1, flexWrap: 'wrap' }}>
          <Chip size="small" color="secondary" variant="filled" label={`Score: ${num(totalScore)}`} />
          {d?.method_pill ? <Chip size="small" color="info" variant="filled" label={String(d.method_pill)} /> : null}
          <Chip size="small" variant="outlined" label={`52W: ${prox52w(ind?.proximity_52w_high_pct)}`} />

          {Array.isArray(badgesRaw)
            ? badgesRaw.slice(0, 6).map((raw: any, i: number) => {
                const b = normBadge(raw);
                return (
                  <Chip
                    key={`badge-${i}`}
                    size="small"
                    variant={b.color === 'default' ? 'outlined' : 'filled'}
                    color={b.color as any}
                    label={b.label}
                  />
                );
              })
            : null}
        </Stack>
      </Box>

      {/* BODY CANVAS */}
      <Box sx={{ px: 3, py: 2, overflowY: 'auto', '& *': { minWidth: 0 } }}>
        {/* 2) Sparkline (placeholder) */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Sparkline (30D)</Typography>
          <Box sx={{ height: 170, borderRadius: 2, bgcolor: '#0c1529', border: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'text.secondary', fontSize: 12 }}>
            Sparkline (30D)
          </Box>
        </Box>

        {/* 3) Indicators grid */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Indicators</Typography>
          <Divider sx={sectionDividerSx} />
          <Grid container spacing={1.25} sx={{ mt: 1 }}>
            <Grid item xs={12} sm={6}><Row label="RSI(14)" value={num(ind?.rsi14, 1)} /></Grid>
            <Grid item xs={12} sm={6}><Row label="ADX(14)" value={num(ind?.adx14, 1)} /></Grid>
            <Grid item xs={12} sm={6}><Row label={`EMA Fast${ind?.ema_fast ? ` (${ind.ema_fast})` : ''}`} value={num(ind?.ema_fast_value, 2)} /></Grid>
            <Grid item xs={12} sm={6}><Row label={`EMA Slow${ind?.ema_slow ? ` (${ind.ema_slow})` : ''}`} value={num(ind?.ema_slow_value, 2)} /></Grid>
            <Grid item xs={12} sm={6}><Row label="ATR %" value={pct(ind?.atr_pct)} /></Grid>
            <Grid item xs={12} sm={6}><Row label="RelVol(20)" value={relvol(ind?.relvol20)} /></Grid>
            <Grid item xs={12}><Row label="vs 52W High" value={prox52w(ind?.proximity_52w_high_pct)} /></Grid>
          </Grid>
        </Box>

        {/* 4) Score breakdown */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Score Breakdown</Typography>
          <Divider sx={sectionDividerSx} />
          <Stack spacing={1.25} sx={{ mt: 1 }}>
            <Stack>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5 }}>Total Score</Typography>
              <Stack direction="row" spacing={1} alignItems="center">
                <Box sx={{ flex: 1 }}>
                  <LinearProgress
                    variant="determinate"
                    value={typeof totalScore === 'number' ? Math.max(0, Math.min(100, totalScore)) : 0}
                    sx={{ height: 10, borderRadius: 999 }}
                  />
                </Box>
                <Typography variant="body2" sx={{ width: 36, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                  {typeof totalScore === 'number' ? Math.round(totalScore) : '—'}
                </Typography>
              </Stack>
            </Stack>

            {/* Show common sub-components if present in either sb.* or older d.* */}
            {('trend_rank' in sb || 'trend_rank' in (d || {})) && (
              <Stack>
                <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5 }}>Trend</Typography>
                <LinearProgress variant="determinate"
                  value={Math.max(0, Math.min(100, Number((sb?.trend_rank ?? d?.trend_rank) || 0)))}
                  sx={{ height: 8, borderRadius: 999 }} />
              </Stack>
            )}
            {('breakout_quality' in sb || 'breakout_quality' in (d || {})) && (
              <Stack>
                <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5 }}>Breakout Quality</Typography>
                <LinearProgress variant="determinate"
                  value={Math.max(0, Math.min(100, Number((sb?.breakout_quality ?? d?.breakout_quality) || 0)))}
                  sx={{ height: 8, borderRadius: 999 }} />
              </Stack>
            )}
            {('relvol' in sb || 'relvol' in (d || {})) && (
              <Stack>
                <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5 }}>Accumulation / RelVol</Typography>
                <LinearProgress variant="determinate"
                  value={Math.max(0, Math.min(100, Number((sb?.relvol ?? d?.relvol) || 0)))}
                  sx={{ height: 8, borderRadius: 999 }} />
              </Stack>
            )}
          </Stack>
        </Box>

        {/* 5) Entry (suggested / locked) */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Entry</Typography>
          <Divider sx={sectionDividerSx} />
          <Stack spacing={0.75} sx={{ mt: 1 }}>
            <Row label="Entry price" value={rup(effectiveEntry)} hint={locked ? 'Locked' : (refs?.entry_reason || 'Suggested')} />
            {/* One-line rationale (text or reasons[0]) */}
            {na?.text ? (
              <Typography variant="caption" color="text.secondary">
                {refs?.entry_reason || na?.refs?.entry_reason || (Array.isArray(na?.reasons) ? na.reasons.join(' · ') : '')}
              </Typography>
            ) : null}
          </Stack>
        </Box>

        {/* 6) Trade toggle & Lock entry (inline) */}
        <Box sx={{ mb: 2 }}>
          <Stack direction="row" alignItems="center" spacing={1.25}>
            <Switch checked={tradeOn} onChange={(e) => setTradeOn(e.target.checked)} />
            <Typography variant="body2">Trade</Typography>
            {locked && <Tooltip title="Entry is locked; adjust via dedicated flow"><InfoOutlinedIcon fontSize="small" /></Tooltip>}
          </Stack>
          {tradeOn && (
            <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap', mt: 1 }}>
              <TextField
                size="small"
                label="Entry price (₹)"
                value={entryPrice}
                onChange={(e) => setEntryPrice(e.target.value)}
                sx={{ width: 220 }}
                inputProps={{ inputMode: 'decimal' }}
                disabled={locked}
              />
              <TextField
                size="small"
                label="Qty"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                sx={{ width: 160 }}
                inputProps={{ inputMode: 'numeric' }}
                disabled={locked}
              />
              <Button variant="contained" disabled={lockDisabled || locked}>Lock entry</Button>
            </Stack>
          )}
        </Box>

        {/* 7) Action block (now from d.action_block, not position) */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Action</Typography>
          <Divider sx={sectionDividerSx} />
          <Stack spacing={0.75} sx={{ mt: 1 }}>
            <Row label="Stop-loss (now)" value={typeof ab?.stop_now === 'number' ? rup(ab?.stop_now) : '—'} hint={ab?.stop_method ? String(ab.stop_method) : 'sell if touched'} />
            <Row
              label="Exit at close if"
              value={typeof ab?.exit_close_threshold === 'number' ? `Close < ${rup(ab?.exit_close_threshold)}` : '—'}
              hint="sell next day if true"
            />
            <Row label="Breakeven" value={String(ab?.breakeven_state ?? '—')} hint="stop won’t go below entry" />
            <Row label="Euphoria" value={String(ab?.euphoria_state ?? '—')} hint="tighter stop & faster EMA" />
            {d?.method_pill ? <Chip size="small" color="info" variant="filled" label={d.method_pill} /> : null}
          </Stack>
        </Box>

        {/* 8) Meters (analog 0–100) */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Meters</Typography>
          <Divider sx={sectionDividerSx} />
          <Grid container spacing={1.5} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <AnalogMeter
                icon={<SpeedIcon fontSize="small" />}
                label="Risk"
                score={meters?.risk?.score_0_100}
                level={meters?.risk?.level}
                basis={meters?.risk?.basis}
              />
            </Grid>
            <Grid item xs={12}>
              <AnalogMeter
                icon={<WhatshotIcon fontSize="small" />}
                label="Euphoria"
                score={meters?.euphoria?.score_0_100}
                level={meters?.euphoria?.level}
                basis={meters?.euphoria?.basis}
              />
            </Grid>
          </Grid>
        </Box>

        {/* 9) Next Action (single line) */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Next Action</Typography>
          <Divider sx={sectionDividerSx} />
          <Stack spacing={0.5} sx={{ mt: 1 }}>
            <Typography variant="body2" sx={{ fontWeight: 700 }}>
              {na?.text || na?.reason || na?.state || '—'}
            </Typography>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ flexWrap: 'wrap', color: 'text.secondary' }}>
              {typeof refs?.ema_n === 'number' && typeof refs?.ema_value === 'number' ? (
                <Chip size="small" variant="filled" label={`EMA${refs.ema_n}=${num(refs.ema_value, 2)}`} />
              ) : null}
              {typeof refs?.entry_suggested === 'number' ? (
                <Chip size="small" variant="filled" label={`Suggested Entry ${rup(refs.entry_suggested)}`} />
              ) : null}
              {typeof refs?.entry_low === 'number' && typeof refs?.entry_high === 'number' ? (
                <Chip size="small" variant="filled" label={`Entry Band ${rup(refs.entry_low)}–${rup(refs.entry_high)}`} />
              ) : null}
              {refs?.entry_type ? <Chip size="small" variant="filled" label={String(refs.entry_type)} /> : null}
              {d?.method_pill ? <Chip size="small" color="info" variant="filled" label={d.method_pill} /> : null}
            </Stack>
          </Stack>
        </Box>

        {/* 10) Alerts (templates now {code, example}) */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: .75 }}>Alerts</Typography>
          <Divider sx={sectionDividerSx} />
          <Stack direction="row" spacing={1} alignItems="center" sx={{ flexWrap: 'wrap', mt: 1 }}>
            {Array.isArray(d?.alert_templates) && d.alert_templates.length > 0
              ? d.alert_templates.map((t: any, i: number) => (
                  <Chip
                    key={`alert-${i}`}
                    icon={<NotificationsActiveIcon />}
                    label={String(t?.code ?? t?.example ?? 'Alert')}
                    variant="outlined"
                  />
                ))
              : ['Price crosses ₹X','Enters breakout','Close < EMAₙ','Breakeven active','Stop hit'].map((lbl) => (
                  <Chip key={lbl} icon={<NotificationsActiveIcon />} label={lbl} variant="outlined" />
                ))}
          </Stack>
        </Box>

        {/* 11) Footer */}
        <Divider sx={{ my: 2 }} />
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pb: 1 }}>
          {(d?.as_of || header?.as_of) ? `As of ${new Date(d?.as_of ?? header?.as_of).toLocaleString()}` : ''}
          {isFetching ? ' · refreshing…' : ''}
          {d?.trading_day ? ` · ${d.trading_day}` : ''}
          {d?.run_id ? ` · Run ${d.run_id}` : d?.resolved_run_id ? ` · Run ${d.resolved_run_id}` : ''}
          {d?.symbol_canon ? ` · ${d.symbol_canon}` : ''}
        </Typography>

        {error ? (
          <Typography variant="body2" color="error" sx={{ mt: 1, pb: 2 }}>
            {(error as any)?.message || 'Failed to load details.'}
          </Typography>
        ) : null}
      </Box>
    </Drawer>
  );
}
