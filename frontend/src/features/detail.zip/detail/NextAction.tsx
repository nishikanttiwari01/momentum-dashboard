import * as React from 'react';
import { Box, Stack, Typography, Chip, Divider } from '@mui/material';
import { num, rup } from './utils';

type Refs = {
  ema_n?: number;
  ema_value?: number;
  entry_suggested?: number;
  entry_low?: number | null;
  entry_high?: number | null;
  entry_type?: string | null;
  // tolerate extra keys without failing
  [k: string]: unknown;
};

type Props = {
  /** Main instruction from API (fallbacks are handled by caller) */
  text?: string;
  /** Reference values that explain the action */
  refs?: Refs;
  /** Optional strategy/method tag */
  method_pill?: string;
  /** Optional reasons array (if backend provides it) */
  reasons?: string[];
};

export default function NextAction({ text, refs = {}, method_pill, reasons }: Props) {
  const hasBand = typeof refs.entry_low === 'number' && typeof refs.entry_high === 'number';
  const hasEma = typeof refs.ema_n === 'number' && typeof refs.ema_value === 'number';

  return (
    <Box sx={{ mb: 2 }}>
      <Typography variant="subtitle2" sx={{ mb: 0.75 }}>Next Action</Typography>
      <Divider sx={{ opacity: 0.2, mb: 1 }} />

      {/* Primary instruction */}
      <Typography variant="body2" sx={{ fontWeight: 700, mb: 0.5 }}>
        {text || '—'}
      </Typography>

      {/* Context line (anchor) */}
      {hasEma ? (
        <Typography variant="caption" color="text.secondary" sx={{ mb: 0.75 }}>
          Anchor: EMA{refs.ema_n} @ {num(refs.ema_value, 2)}
        </Typography>
      ) : null}

      {/* Plan summary (compact, not cluttered) */}
      <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap', mb: 0.75 }}>
        {typeof refs.entry_suggested === 'number' && (
          <Chip size="small" variant="outlined" label={`Suggested Entry ${rup(refs.entry_suggested)}`} />
        )}
        {hasBand && (
          <Chip size="small" variant="outlined" label={`Entry Band ${rup(refs.entry_low as number)}–${rup(refs.entry_high as number)}`} />
        )}
        {refs.entry_type && <Chip size="small" variant="outlined" label={String(refs.entry_type)} />}
        {method_pill && <Chip size="small" color="info" variant="filled" label={method_pill} />}
      </Stack>

      {/* Why (optional) */}
      {Array.isArray(reasons) && reasons.length > 0 && (
        <Stack spacing={0.5} sx={{ mt: 0.25 }}>
          <Typography variant="caption" color="text.secondary">Why</Typography>
          <Stack direction="row" spacing={0.75} sx={{ flexWrap: 'wrap' }}>
            {reasons.slice(0, 6).map((r, i) => (
              <Chip key={i} size="small" variant="filled" color="default" label={r} />
            ))}
          </Stack>
        </Stack>
      )}
    </Box>
  );
}
