export default function Dashboard(){ return <div>Dashboard</div>; }
import * as React from 'react';
import {
  AppBar, Toolbar, Box, Typography, Container, Paper, Stack,
  FormControl, InputLabel, Select, MenuItem, IconButton, Divider
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import MomentumTable from '../components/MomentumTable';
import RightDrawer from '../components/RightDrawer';

export default function Dashboard() {
  // Drawer state
  const [symbol, setSymbol] = React.useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = React.useState(false);

  // Auto-refresh selector
  // Options: Off, 15s, 30s, 60s, FocusOnly (DataGrid refetch on window focus)
  type RefreshOpt = 'off' | '15' | '30' | '60' | 'focus';
  const [refresh, setRefresh] = React.useState<RefreshOpt>('off');

  // Convert to ms for the table prop
  const refetchIntervalMs = React.useMemo(() => {
    if (refresh === 'off') return false as const;
    if (refresh === 'focus') return false as const; // we still keep react-query's refetchOnWindowFocus behavior
    return Number(refresh) * 1000;
  }, [refresh]);

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <AppBar position="sticky" elevation={0}>
        <Toolbar sx={{ gap: 2 }}>
          <Typography variant="h6">Momentum Dashboard</Typography>

          <Box sx={{ flex: 1 }} />

          <Stack direction="row" spacing={2} alignItems="center">
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel id="refresh-label">Auto refresh</InputLabel>
              <Select
                labelId="refresh-label"
                label="Auto refresh"
                value={refresh}
                onChange={(e) => setRefresh(e.target.value as RefreshOpt)}
              >
                <MenuItem value="off">Off</MenuItem>
                <MenuItem value="15">Every 15s</MenuItem>
                <MenuItem value="30">Every 30s</MenuItem>
                <MenuItem value="60">Every 60s</MenuItem>
                <MenuItem value="focus">Only when focused</MenuItem>
              </Select>
            </FormControl>

            <IconButton
              aria-label="refresh-now"
              onClick={() => window.dispatchEvent(new Event('focus'))}
              title="Refresh now"
            >
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Stack>
        </Toolbar>
      </AppBar>

      {/* Content */}
      <Container maxWidth="xl" sx={{ py: 2, flex: 1, width: '100%' }}>
        <Paper sx={{ p: 1.5 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
            <Typography variant="subtitle2">Screener</Typography>
            <Typography variant="caption" color="text.secondary">
              Sorted by score (desc)
            </Typography>
          </Stack>
          <Divider sx={{ mb: 1 }} />
          <MomentumTable
            onSelectSymbol={(s) => {
              setSymbol(s);
              setDrawerOpen(true);
            }}
            refetchIntervalMs={refetchIntervalMs}
          />
        </Paper>
      </Container>

      {/* Right Drawer */}
      <RightDrawer
        symbol={symbol}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      />
    </Box>
  );
}
