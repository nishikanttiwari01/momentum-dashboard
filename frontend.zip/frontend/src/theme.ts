import { createTheme } from '@mui/material/styles';

const fontStack = [
  'Inter',
  'Segoe UI',
  'Roboto',
  'Helvetica Neue',
  'Arial',
  'Noto Sans',
  'sans-serif',
].join(',');

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: '#4F46E5' }, // indigo-600
    secondary: { main: '#22C55E' }, // green-500
    background: { default: '#f7f8fb' },
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily: fontStack,
    h6: { fontWeight: 700 },
    subtitle2: { fontWeight: 700 },
    body2: { fontSize: 13.5 },
    caption: { fontSize: 12 },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        'html, body, #root': { height: '100%' },
        body: { color: '#0f172a' },
      },
    },
    MuiPaper: {
      defaultProps: { elevation: 0 },
      styleOverrides: { root: { borderRadius: 16 } },
    },
    MuiAppBar: {
      styleOverrides: { root: { background: '#ffffff', color: '#111827', borderBottom: '1px solid #e5e7eb' } },
    },
    MuiToolbar: {
      styleOverrides: { root: { minHeight: 64 } },
    },
    MuiButton: {
      defaultProps: { size: 'small' },
      styleOverrides: { root: { textTransform: 'none', fontWeight: 600, borderRadius: 10 } },
    },
    MuiChip: {
      defaultProps: { size: 'small' },
      styleOverrides: { root: { borderRadius: 8 } },
    },
    MuiDrawer: {
      styleOverrides: { paper: { borderLeft: '1px solid #e5e7eb' } },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          border: 'none',
          background: '#fff',
        },
        columnHeaders: {
          background: '#f3f4f6',
          borderBottom: '1px solid #e5e7eb',
          fontWeight: 700,
        },
        cell: {
          borderBottom: '1px solid #f1f5f9',
        },
      },
    },
  },
});

export default theme;
