import * as React from 'react';
import { DataGrid, GridColDef, GridRenderCellParams, GridValueGetterParams } from '@mui/x-data-grid';
import { Chip, Box, LinearProgress, Tooltip, Button } from '@mui/material';
import { useScreener } from '@/lib/hooks';
import type { ScreenerRow } from '@/lib/api/types';

type Props = {
  /** Called when user wants to open the right drawer for a row */
  onSelectSymbol?: (symbol: string) => void;
  /** Optional: override auto-refresh interval (ms). If omitted, wrapper defaults apply. */
  refetchIntervalMs?: number | false;
};

const percent = (v?: number) =>
  typeof v === 'number' && isFinite(v) ? `${v.toFixed(2)}%` : '—';

const price = (v?: number) =>
  typeof v === 'number' && isFinite(v) ? v.toFixed(2) : '—';

const relvol = (v?: number) =>
  typeof v === 'number' && isFinite(v) ? `${v.toFixed(2)}×` : '—';

/** Render 52W proximity as human text, e.g. "2.3% above" / "5.1% below" */
const proximityText = (p?: number) => {
  if (typeof p !== 'number' || !isFinite(p)) return '—';
  if (p === 0) return 'At 52W high';
  return p > 0 ? `${percent(p)} above` : `${percent(Math.abs(p))} below`;
};

const scoreBar = (v?: number) => {
  if (typeof v !== 'number' || !isFinite(v)) return '—';
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
      <Box sx={{ flex: 1 }}>
        <LinearProgress variant="determinate" value={Math.max(0, Math.min(100, v))} />
      </Box>
      <Box sx={{ width: 38, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
        {Math.round(v)}
      </Box>
    </Box>
  );
};

const RecommendationChip: React.FC<{ value?: string }> = ({ value }) => {
  const val = (value || '').toUpperCase();
  const color = val === 'YES' ? 'success' : val === 'NO' ? 'error' : 'default';
  return <Chip size="small" label={val || '—'} color={color as any} variant="outlined" />;
};

export default function MomentumTable({ onSelectSymbol, refetchIntervalMs = false }: Props) {
  // Fetch latest screener snapshot (items + run/as_of lineage)
  const { data, isLoading, isFetching, error } = useScreener(
    /* params */ undefined,
    { refetchIntervalMs }
  );

  const rows: ScreenerRow[] = React.useMemo(() => data?.items ?? [], [data]);

  const columns = React.useMemo<GridColDef<ScreenerRow>[]>(
    () => [
      {
        field: 'name',
        headerName: 'Name / Ticker',
        minWidth: 220,
        flex: 1.2,
        valueGetter: (p: GridValueGetterParams<ScreenerRow, unknown>) =>
          p.row?.name && p.row?.symbol ? `${p.row.name} (${p.row.symbol})` : p.row?.symbol ?? '—',
      },
      {
        field: 'last',
        headerName: 'Price',
        width: 100,
        type: 'number',
        valueFormatter: (p) => price(p.value as number),
      },
      {
        field: 'change_pct',
        headerName: '% 1D',
        width: 90,
        type: 'number',
        valueFormatter: (p) => percent(p.value as number),
        renderCell: (p: GridRenderCellParams<number>) => {
          const v = p.value ?? 0;
          const isUp = typeof v === 'number' && v >= 0;
          return (
            <Box sx={{ color: isUp ? 'success.main' : 'error.main', fontWeight: 600 }}>
              {percent(v)}
            </Box>
          );
        },
        sortComparator: (a, b) => (a ?? 0) - (b ?? 0),
      },
      {
        field: 'ret_1w',
        headerName: '% 1W',
        width: 90,
        type: 'number',
        valueFormatter: (p) => percent(p.value as number),
        renderCell: (p: GridRenderCellParams<number>) => {
          const v = p.value ?? 0;
          const isUp = typeof v === 'number' && v >= 0;
          return (
            <Box sx={{ color: isUp ? 'success.main' : 'error.main', fontWeight: 600 }}>
              {percent(v)}
            </Box>
          );
        },
      },
      {
        field: 'rsi14',
        headerName: 'RSI(14)',
        width: 90,
        type: 'number',
        valueFormatter: (p) => (typeof p.value === 'number' ? p.value.toFixed(1) : '—'),
      },
      {
        field: 'adx14',
        headerName: 'ADX(14)',
        width: 95,
        type: 'number',
        valueFormatter: (p) => (typeof p.value === 'number' ? p.value.toFixed(1) : '—'),
      },
      {
        field: 'proximity_52w_high_pct',
        headerName: 'vs 52W High',
        minWidth: 130,
        flex: 0.9,
        valueGetter: (p) => proximityText(p.row?.proximity_52w_high_pct as number | undefined),
      },
      {
        field: 'relvol20',
        headerName: 'RelVol(20)',
        width: 110,
        type: 'number',
        valueFormatter: (p) => relvol(p.value as number),
      },
      {
        field: 'score',
        headerName: 'Score',
        minWidth: 160,
        flex: 1,
        type: 'number',
        renderCell: (p: GridRenderCellParams<number>) => scoreBar(p.value as number | undefined),
        sortComparator: (a, b) => (a ?? 0) - (b ?? 0),
      },
      {
        field: 'recommendation',
        headerName: 'Reco',
        width: 90,
        renderCell: (p: GridRenderCellParams<string>) => <RecommendationChip value={p.value} />,
      },
      {
        field: 'reason',
        headerName: 'Reason',
        minWidth: 240,
        flex: 1.6,
        renderCell: (p: GridRenderCellParams<string>) =>
          p.value ? (
            <Tooltip title={p.value}>
              <Box sx={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {p.value}
              </Box>
            </Tooltip>
          ) : (
            '—'
          ),
      },
      {
        field: 'badges',
        headerName: 'Badges',
        minWidth: 180,
        flex: 1.2,
        renderCell: (p: GridRenderCellParams<string[]>) => {
          const list = Array.isArray(p.value) ? p.value : [];
          if (!list.length) return '—';
          return (
            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
              {list.map((b, i) => (
                <Chip key={`${p.id}-b-${i}`} size="small" label={b} />
              ))}
            </Box>
          );
        },
        sortable: false,
      },
      {
        field: '__actions',
        headerName: '',
        width: 110,
        sortable: false,
        filterable: false,
        renderCell: (p) => (
          <Button
            size="small"
            variant="outlined"
            onClick={(e) => {
              e.stopPropagation();
              onSelectSymbol?.((p.row as ScreenerRow).symbol);
            }}
          >
            Details
          </Button>
        ),
      },
    ],
    [onSelectSymbol]
  );

  const handleRowClick = React.useCallback(
    (params: any) => {
      const row = params?.row as ScreenerRow | undefined;
      if (row?.symbol) onSelectSymbol?.(row.symbol);
    },
    [onSelectSymbol]
  );

  // Basic pagination (client-side for now; can switch to server-side by mapping DataGrid state to /screener params)
  const [pageSize, setPageSize] = React.useState<number>(50);

  return (
    <Box sx={{ height: 'calc(100vh - 180px)', width: '100%' }}>
      <DataGrid
        rows={rows as any}
        columns={columns}
        getRowId={(r) => (r as ScreenerRow).symbol}
        loading={isLoading || isFetching}
        disableRowSelectionOnClick
        onRowDoubleClick={handleRowClick}
        initialState={{
          sorting: { sortModel: [{ field: 'score', sort: 'desc' }] },
          pagination: { paginationModel: { pageSize } },
        }}
        pageSizeOptions={[25, 50, 100, 200]}
        onPaginationModelChange={(m) => setPageSize(m.pageSize)}
        density="compact"
        sx={{
          '& .MuiDataGrid-columnHeaders': { fontWeight: 700 },
          '& .MuiDataGrid-cell': { fontVariantNumeric: 'tabular-nums' },
        }}
      />
      {error ? (
        <Box sx={{ mt: 1, color: 'error.main', fontSize: 13 }}>
          {(error as any)?.message || 'Failed to load screener.'}
        </Box>
      ) : null}
    </Box>
  );
}
