import { Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Screener from './pages/Screener';
import DetailRightDrawer from './pages/DetailRightDrawer';
import Watchlist from './pages/Watchlist';
import History from './pages/History';
import Alerts from './pages/Alerts';
import Settings from './pages/Settings';

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/screener" element={<Screener />} />
      <Route path="/detail" element={<DetailRightDrawer />} />
      <Route path="/watchlist" element={<Watchlist />} />
      <Route path="/history" element={<History />} />
      <Route path="/alerts" element={<Alerts />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
