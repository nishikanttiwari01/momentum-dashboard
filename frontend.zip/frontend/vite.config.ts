import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  appType: 'spa',
  root: '.',       // serve from frontend folder
  base: '/',
  plugins: [react()],
  server: {
    host: '0.0.0.0',  // bind IPv4 all; avoids ::1/localhost quirks
    port: 5174,       // new port to avoid any stale binding
    strictPort: true,
    open: false
  }
});
